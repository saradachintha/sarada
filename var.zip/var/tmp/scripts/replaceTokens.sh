﻿#!bin/bash
# Note: Due to slinux os not avaible commands are not testes and syntax may be incorrect in some places.

# check the number of input parameters, if not 3 give the syntx and exit from script
if [ "$#" -ne 3 ]; then
  echo "Usage: ./replaceTokens.sh ../input/index.html ../conf/XXXX.properties ../output/index.html" >&2
  exit 1
fi


file1 ="$1"
file2= "$2"
file3= "$3"

# copy input file to outputile
cp $file1 $file3


if [ -f  "$file2" ]
then

#read every line
#-r prevents backslash escapes from being interpreted.
#|| [[ -n $line ]] prevents the last line from being ignored if it doesn't end with a \n (since read returns a non-zero exit code when it encounters EOF).
		
	while read -r line || [[ -n "$line" ]]; do
	
		#extract value and variable using awk with "=" as separator and then read them to variable and its value

		echo $line | awk -F=  '{print $1 $2}'| read varname varvalue

		#append square beackets

		varname= "[[$varname]]" 
		varvalue ="[[$varvalue]]"
		
		# find the varibles and replace with its value in output file. this happens for every line in confi file. so all the values will be replaced as per config file.
		# replacement used here is globle replacement.we can also use /1 in place of /g if we want to replace only first occurance
		
		sed -i "s/$varname/$varvalue/g" $file3
   
	done < "$file2"

else

	echo " $file2 file not found.check the file"

fi

